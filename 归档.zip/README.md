# 🎯 火炮棋 (Cannon Chess)

一款经典策略博弈游戏，体验大炮与小兵之间的智慧对决。

![Vue](https://img.shields.io/badge/Vue-3.5-4FC08D?logo=vue.js)
![TypeScript](https://img.shields.io/badge/TypeScript-5.9-3178C6?logo=typescript)
![WebSocket](https://img.shields.io/badge/WebSocket-实时通信-010101)
![License](https://img.shields.io/badge/License-MIT-yellow)

## ✨ 功能特性

- 🎮 **三种游戏模式**：本地双人、AI对战、联机对战
- 🤖 **多难度AI**：简单/中等/困难三档难度
- 🌐 **实时联机**：WebSocket实现低延迟对战
- 📱 **响应式设计**：完美适配移动端和PC端
- 🎨 **精美UI**：玻璃拟态风格，流畅动画效果

## 🎲 游戏规则

| 阵营 | 棋子数量 | 移动规则 | 胜利条件 |
|------|----------|----------|----------|
| 大炮方 | 2枚 | 每次移动一格（上下左右），可隔空吃子 | 消灭小兵至少于6个 |
| 小兵方 | 18枚 | 每次移动一格（上下左右） | 围困大炮使其无法移动 |

**特殊规则**：大炮与小兵在同一直线上且中间隔着一个空格时，大炮可吃掉该小兵。

## 📁 项目结构

```
cannon-antigravity/
├── cannon-game/          # 前端项目 (Vue 3 + Vite)
│   ├── src/
│   │   ├── components/   # UI组件
│   │   ├── core/         # 游戏引擎
│   │   ├── network/      # WebSocket通信
│   │   └── views/        # 页面视图
│   └── package.json
├── cannon-server/        # 后端项目 (Node.js + WebSocket)
│   ├── src/
│   │   ├── server.ts     # 服务入口
│   │   └── RoomManager.ts # 房间管理
│   └── package.json
├── DEPLOY.md             # 部署文档
└── README.md             # 项目说明
```

## 🚀 快速开始

### 环境要求

- Node.js >= 18.0.0
- npm >= 8.0.0

### 安装与运行

```bash
# 克隆项目
git clone https://github.com/HuFakai/cannon.git
cd cannon

# 启动后端
cd cannon-server
npm install
npm run dev

# 新开终端，启动前端
cd cannon-game
npm install
npm run dev
```

访问 `http://localhost:5173` 开始游戏。

## 🧪 测试

```bash
cd cannon-game
npm run test:run
```

## 📦 构建部署

详细部署指南请参阅 [DEPLOY.md](./DEPLOY.md)

```bash
# 构建前端
cd cannon-game
npm run build

# 构建后端
cd cannon-server
npm run build
```

## 🛠️ 技术栈

| 层级 | 技术 |
|------|------|
| 前端框架 | Vue 3 + Composition API |
| 构建工具 | Vite 7 |
| 类型系统 | TypeScript 5.9 |
| 路由管理 | Vue Router 4 |
| 实时通信 | 原生 WebSocket |
| 后端运行时 | Node.js |
| 后端框架 | Express 5 |
| 测试框架 | Vitest |

## 🎯 游戏截图

### 主页
玻璃拟态风格的游戏主界面，提供三种游戏模式入口。

### AI对战
与不同难度的AI进行策略对决，实时显示双方棋子数量。

### 联机对战
创建房间或加入房间，与好友进行实时对战。

## 📄 许可证

[MIT License](LICENSE)

## 👨‍💻 作者

- **HuFakai** - [GitHub](https://github.com/HuFakai)

---

如果这个项目对你有帮助，欢迎给个 ⭐ Star！
